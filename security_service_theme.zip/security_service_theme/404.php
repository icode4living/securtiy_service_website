<?php

    get_header();
    ?>

<div class="main">
<div class="title-center">
    <h1 style="font-size:3.5rem">Ooops! You weren't supposed to see this</h1>
    <p>The page you are looking for no longer exists.
    Return to the <a href="/">home page</a> and remember: you haven't seen anything.
</p>
   </div>

</div>

<?php get_footer();?>