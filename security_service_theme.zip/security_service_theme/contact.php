<?php /**Template Name: contact Page */ ?>

<?php get_header(); ?>
<div class="page-title">
    <div class="title-text">
        <span class="breadcrumbs"><a href="/">Home</a> > <a href="/contact">Contact Us</a></span>
        <h1>Contact Us</h1>

    </div>
</div>
<div class="map-area">
    <div class="map">
        
    </div>
</div>
<div class="main">
<div class="form-area">
<!--WP form goes here-->

<form class="form" id="contact-form">
    <span style="left:50px;" class="title-label"><small>REACH OUT TO US</small></span>
<h2>Send Us a message</h2>
    <div class="form-group">
    <label>Full Names</label>
    <input type="text"  id="fname">
</div>
<div class="form-group">
    <label>Email</label>
    <input type="text"  id="email">
</div>
<div class="form-group">
    <label>Phone</label>
    <input type="tel"  id="phone">
</div>
<div class="form-group">
    <textarea rows="5"  placeholder="message here" id="message"></textarea>
</div>
<div class="form-group">
    <button type="submit" id="subBtn">
        Send message
    </button>
</div>
</form>

</div>
</div>

<div class = "contact-list">
<div class="grid">
<div class="card contact-icon">
    <h1><i class="fa-brands fa-square-whatsapp"></i></h1>
    <h2><a href="https://wa.me/44747481745">+44747481745</a></h2>
</div>
<div class="card contact-icon">
    <h1 ><i class="fa-solid fa-square-phone-flip"></i></h1>
    <h2><a href="tel:+2348084220086">+234-80-8422-0086</a></h2>
</div>

<div class="card contact-icon">
    <h1 ><i class="fa-solid fa-square-envelope"></i></h1>
    <h2><a href="mailto:info@tobrossecurity.org">info@tobrossecurity.org</a></h2>
</div>
</div>

</div>
</div>

<?php get_footer();?>