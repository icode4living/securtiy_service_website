jQuery(document).ready(function(){
   
     jQuery("#contact-form").submit(function(e){
         e.preventDefault();
 jQuery("#subBtn").html("Please wait..");
          let _email = jQuery("#email").val();
let _fname = jQuery("#fname").val();
//let lname = jQuery("#lname").val();
let _phone = jQuery("#phone").val();
let _message = jQuery("#message").val();
       //  jQuery('.modal-container').css('display','block');
      jQuery.ajax({
          type:'post',
          url:localize._ajax_url,
          //dataType:'json',
          data:{action:'save_contact_form',
		email:_email,
		phone:_phone,
		fname:_fname,
		//'lname':lname,
		message:_message,
		}
          
      }).done((resp)=>{
         // cookieSetter('isSubscriber','false',360);
    //success response
   console.log(resp);
  // jQuery("#newsletter").css('display','none');
alert('Thanks for contatacting us');
      }).fail((res)=>{
          //fial response
          console.log(res);

     });
      
      });
 
 });
